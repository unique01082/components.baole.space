// @baole/ui — Component Library Barrel Export

// Utilities
export { cn } from "../../lib/baole-utils";

// Components
export { Button, buttonVariants } from "./button";
export type { ButtonProps } from "./button";

export {
  Card,
  CardHeader,
  CardFooter,
  CardTitle,
  CardDescription,
  CardContent,
  CardAction,
} from "./card";

export { Badge, badgeVariants } from "./badge";
export type { BadgeProps } from "./badge";

export { Input, inputVariants } from "./input";
export type { InputProps } from "./input";

export { Separator } from "./separator";

export { Skeleton } from "./skeleton";

// Note: This is a partial implementation showcasing the core components.
// The full @baole/ui library includes 45+ components.
// Additional components to be exported:
// - Accordion, Alert, AlertDialog, AspectRatio, Avatar
// - Breadcrumb, Calendar, Carousel, Chart, Checkbox
// - Collapsible, Command, ContextMenu
// - Dialog, Drawer, DropdownMenu
// - Form, HoverCard
// - InputOTP, Label
// - Menubar, NavigationMenu
// - Pagination, Popover, Progress
// - RadioGroup, Resizable
// - ScrollArea, Select, Sheet, Sidebar, Slider, Sonner, Switch
// - Table, Tabs, Textarea, Toggle, ToggleGroup, Tooltip
